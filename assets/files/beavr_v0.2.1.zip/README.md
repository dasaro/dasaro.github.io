# Beavr

An unofficial Beamer theme for University of Verona slides, for lecturers and students.

## Files

- `beamerthemebeavr.sty` and the color, inner and outer theme files: the theme itself.
- `main.tex`: a short example deck. Compile it with `pdflatex main.tex`.
- `logo_univr.png`: the university logo used on the title page and in the footer.

## Usage

Keep the `.sty` files and the logo next to your `.tex` file, then:

```latex
\documentclass{beamer}      % or \documentclass[aspectratio=169]{beamer}
\def\beavrcolor{0}          % 0 orange/red, 1 gray/blue, 2 ochre/blue, other values gray
% \def\beavrlogo{mylogo.png} % optional: use a different logo file
\usetheme{beavr}
```

The title graphics appear only on the frame that contains `\titlepage`.

## The UniVR logo

This template is not an official University of Verona product. The university logo is not covered by the license below: its use is governed by the university's visual identity guidelines, and some uses require prior approval from the central offices. Check the official documentation before using the logo in public (talks, posters, published slides): https://www.univr.it/it/organizzazione/sistema-bibliotecario-di-ateneo/comunicazione-visiva-univr

## License

The `.sty` and `.tex` files are released under the Creative Commons CC BY-NC 4.0 license.
Author: Fabio Aurelio D'Asaro (fabioaurelio.dasaro at univr.it).

## Changes in v0.2.1

- The footer logo is anchored to the right edge of the slide, so 16:9 decks work.
- The slide number counts frames, so `\pause` no longer makes it jump.
- The title graphics follow the `\titlepage` frame: a deck without a title page, or a title frame with `\pause`, now renders correctly.
- Example deck: fixed the missing space after `\LaTeX` in the title and the author field that produced garbled PDF metadata.
